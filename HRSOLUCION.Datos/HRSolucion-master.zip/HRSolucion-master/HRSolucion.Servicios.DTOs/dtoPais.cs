﻿namespace HRSolucion.Servicios.DTOs
{
    public class dtoPais
    {
    }
}
