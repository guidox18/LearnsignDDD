﻿namespace HRSolucion.Servicios.DTOs
{
    public class dtoRegion
    {
        public int IDRegion { get; set; }
        public string NombreRegion { get; set; }
    }
}
